(() => {
  'use strict';

  const card = document.getElementById('pwaInstallCard');
  const installButton = document.getElementById('pwaInstallBtn');
  const dialog = document.getElementById('pwaInstallDialog');
  const dialogTitle = document.getElementById('pwaInstallTitle');
  const dialogIntro = document.getElementById('pwaInstallIntro');
  const dialogSteps = document.getElementById('pwaInstallSteps');
  const closeButton = document.getElementById('pwaInstallClose');
  const okButton = document.getElementById('pwaInstallOk');

  if (!card || !installButton) return;

  let deferredPrompt = null;
  const standalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent) ||
    (window.navigator.platform === 'MacIntel' && window.navigator.maxTouchPoints > 1);

  function closeDialog() {
    if (dialog && typeof dialog.close === 'function' && dialog.open) dialog.close();
    else if (dialog) dialog.removeAttribute('open');
  }

  function showInstructions({ title, intro, steps }) {
    if (!dialog || !dialogTitle || !dialogIntro || !dialogSteps) {
      window.alert(`${intro}\n\n${steps.map((step, index) => `${index + 1}. ${step}`).join('\n')}`);
      return;
    }
    dialogTitle.textContent = title;
    dialogIntro.textContent = intro;
    dialogSteps.replaceChildren();
    for (const step of steps) {
      const item = document.createElement('li');
      item.textContent = step;
      dialogSteps.appendChild(item);
    }
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', 'open');
  }

  if (standalone()) card.hidden = true;

  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredPrompt = event;
  });

  window.addEventListener('appinstalled', () => {
    card.hidden = true;
    deferredPrompt = null;
  });

  installButton.addEventListener('click', async () => {
    if (standalone()) {
      card.hidden = true;
      return;
    }

    if (isIOS()) {
      showInstructions({
        title: 'На экран «Домой»',
        intro: 'На iPhone добавление выполняется через Safari — отдельный APK для iPhone не нужен.',
        steps: [
          'Откройте эту же ссылку в браузере Safari.',
          'Нажмите кнопку «Поделиться» (квадрат со стрелкой вверх).',
          'Выберите «На экран Домой» / Add to Home Screen. Если пункта нет, откройте «Ещё».',
          'Подтвердите название «Мой Маркет PRO» и нажмите «Добавить».'
        ]
      });
      return;
    }

    if (deferredPrompt) {
      const promptEvent = deferredPrompt;
      deferredPrompt = null;
      try {
        await promptEvent.prompt();
        const choice = await promptEvent.userChoice;
        if (choice && choice.outcome === 'accepted') {
          installButton.textContent = 'Добавлено';
          card.hidden = true;
          return;
        }
      } catch (error) {
        console.warn('PWA install prompt unavailable:', error);
      }
    }

    showInstructions({
      title: 'Добавить на телефон',
      intro: 'Если окно установки не появилось, добавьте сайт через меню браузера.',
      steps: [
        'Откройте сайт в Google Chrome.',
        'Нажмите меню браузера ⋮ в правом верхнем углу.',
        'Выберите «Установить приложение» или «Добавить на главный экран».',
        'Подтвердите установку и найдите значок «Мой Маркет PRO» на экране телефона.'
      ]
    });
  });

  closeButton?.addEventListener('click', closeDialog);
  okButton?.addEventListener('click', closeDialog);
  dialog?.addEventListener('click', event => {
    if (event.target === dialog) closeDialog();
  });

  if ('serviceWorker' in navigator && window.location.protocol === 'https:') {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js', { scope: './' })
        .catch(error => console.warn('Service worker registration failed:', error));
    });
  }
})();
